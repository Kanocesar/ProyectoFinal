﻿namespace yonunca
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labfecha = new System.Windows.Forms.Label();
            this.fecha = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.RadioButton();
            this.conectar = new System.Windows.Forms.Button();
            this.contraseña = new System.Windows.Forms.TextBox();
            this.nombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.desconectar = new System.Windows.Forms.Button();
            this.ganador = new System.Windows.Forms.RadioButton();
            this.aceptar = new System.Windows.Forms.Button();
            this.pregunta = new System.Windows.Forms.RadioButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.registrarse = new System.Windows.Forms.RadioButton();
            this.eliminar = new System.Windows.Forms.RadioButton();
            this.Invitar = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chat = new System.Windows.Forms.ListBox();
            this.textoo = new System.Windows.Forms.TextBox();
            this.enviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labfecha
            // 
            this.labfecha.AutoSize = true;
            this.labfecha.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labfecha.Location = new System.Drawing.Point(39, 246);
            this.labfecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labfecha.Name = "labfecha";
            this.labfecha.Size = new System.Drawing.Size(45, 20);
            this.labfecha.TabIndex = 39;
            this.labfecha.Text = "Fecha";
            // 
            // fecha
            // 
            this.fecha.Location = new System.Drawing.Point(113, 246);
            this.fecha.Margin = new System.Windows.Forms.Padding(4);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(287, 22);
            this.fecha.TabIndex = 40;
            // 
            // login
            // 
            this.login.AutoSize = true;
            this.login.Location = new System.Drawing.Point(195, 201);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(64, 21);
            this.login.TabIndex = 38;
            this.login.TabStop = true;
            this.login.Text = "Login";
            this.login.UseVisualStyleBackColor = true;
            // 
            // conectar
            // 
            this.conectar.Location = new System.Drawing.Point(12, 12);
            this.conectar.Name = "conectar";
            this.conectar.Size = new System.Drawing.Size(1258, 58);
            this.conectar.TabIndex = 37;
            this.conectar.Text = "CONNECT";
            this.conectar.UseVisualStyleBackColor = true;
            this.conectar.Click += new System.EventHandler(this.conectar_Click);
            // 
            // contraseña
            // 
            this.contraseña.Location = new System.Drawing.Point(195, 152);
            this.contraseña.Margin = new System.Windows.Forms.Padding(4);
            this.contraseña.Name = "contraseña";
            this.contraseña.Size = new System.Drawing.Size(338, 22);
            this.contraseña.TabIndex = 36;
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(195, 106);
            this.nombre.Margin = new System.Windows.Forms.Padding(4);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(338, 22);
            this.nombre.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 152);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 34;
            this.label1.Text = "Contraseña";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 106);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 32);
            this.label2.TabIndex = 33;
            this.label2.Text = "Nombre";
            // 
            // desconectar
            // 
            this.desconectar.Location = new System.Drawing.Point(25, 490);
            this.desconectar.Name = "desconectar";
            this.desconectar.Size = new System.Drawing.Size(1245, 58);
            this.desconectar.TabIndex = 46;
            this.desconectar.Text = "DISCONNECT";
            this.desconectar.UseVisualStyleBackColor = true;
            this.desconectar.Click += new System.EventHandler(this.desconectar_Click);
            // 
            // ganador
            // 
            this.ganador.AutoSize = true;
            this.ganador.Location = new System.Drawing.Point(195, 310);
            this.ganador.Name = "ganador";
            this.ganador.Size = new System.Drawing.Size(85, 21);
            this.ganador.TabIndex = 44;
            this.ganador.TabStop = true;
            this.ganador.Text = "Ganador";
            this.ganador.UseVisualStyleBackColor = true;
            // 
            // aceptar
            // 
            this.aceptar.Location = new System.Drawing.Point(44, 361);
            this.aceptar.Name = "aceptar";
            this.aceptar.Size = new System.Drawing.Size(356, 47);
            this.aceptar.TabIndex = 43;
            this.aceptar.Text = "Aceptar";
            this.aceptar.UseVisualStyleBackColor = true;
            this.aceptar.Click += new System.EventHandler(this.aceptar_Click);
            // 
            // pregunta
            // 
            this.pregunta.AutoSize = true;
            this.pregunta.Location = new System.Drawing.Point(298, 310);
            this.pregunta.Name = "pregunta";
            this.pregunta.Size = new System.Drawing.Size(87, 21);
            this.pregunta.TabIndex = 51;
            this.pregunta.TabStop = true;
            this.pregunta.Text = "Pregunta";
            this.pregunta.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(602, 76);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(203, 212);
            this.listBox1.TabIndex = 53;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // registrarse
            // 
            this.registrarse.AutoSize = true;
            this.registrarse.Location = new System.Drawing.Point(298, 201);
            this.registrarse.Name = "registrarse";
            this.registrarse.Size = new System.Drawing.Size(102, 21);
            this.registrarse.TabIndex = 54;
            this.registrarse.TabStop = true;
            this.registrarse.Text = "Registrarse";
            this.registrarse.UseVisualStyleBackColor = true;
            this.registrarse.CheckedChanged += new System.EventHandler(this.registrarse_CheckedChanged);
            // 
            // eliminar
            // 
            this.eliminar.AutoSize = true;
            this.eliminar.Location = new System.Drawing.Point(454, 201);
            this.eliminar.Name = "eliminar";
            this.eliminar.Size = new System.Drawing.Size(79, 21);
            this.eliminar.TabIndex = 55;
            this.eliminar.TabStop = true;
            this.eliminar.Text = "Eliminar";
            this.eliminar.UseVisualStyleBackColor = true;
            // 
            // Invitar
            // 
            this.Invitar.Location = new System.Drawing.Point(862, 161);
            this.Invitar.Name = "Invitar";
            this.Invitar.Size = new System.Drawing.Size(250, 47);
            this.Invitar.TabIndex = 56;
            this.Invitar.Text = "Invitar";
            this.Invitar.UseVisualStyleBackColor = true;
            this.Invitar.Click += new System.EventHandler(this.Invitar_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(967, 106);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(145, 22);
            this.textBox1.TabIndex = 57;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(858, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 32);
            this.label3.TabIndex = 58;
            this.label3.Text = "Nombre";
            // 
            // chat
            // 
            this.chat.FormattingEnabled = true;
            this.chat.ItemHeight = 16;
            this.chat.Location = new System.Drawing.Point(909, 260);
            this.chat.Name = "chat";
            this.chat.Size = new System.Drawing.Size(203, 212);
            this.chat.TabIndex = 59;
            // 
            // textoo
            // 
            this.textoo.Location = new System.Drawing.Point(1126, 361);
            this.textoo.Margin = new System.Windows.Forms.Padding(4);
            this.textoo.Name = "textoo";
            this.textoo.Size = new System.Drawing.Size(174, 22);
            this.textoo.TabIndex = 60;
            // 
            // enviar
            // 
            this.enviar.Location = new System.Drawing.Point(1125, 405);
            this.enviar.Name = "enviar";
            this.enviar.Size = new System.Drawing.Size(175, 47);
            this.enviar.TabIndex = 61;
            this.enviar.Text = "Enviar";
            this.enviar.UseVisualStyleBackColor = true;
            this.enviar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1312, 589);
            this.Controls.Add(this.enviar);
            this.Controls.Add(this.textoo);
            this.Controls.Add(this.chat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Invitar);
            this.Controls.Add(this.eliminar);
            this.Controls.Add(this.registrarse);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.pregunta);
            this.Controls.Add(this.desconectar);
            this.Controls.Add(this.ganador);
            this.Controls.Add(this.aceptar);
            this.Controls.Add(this.labfecha);
            this.Controls.Add(this.fecha);
            this.Controls.Add(this.login);
            this.Controls.Add(this.conectar);
            this.Controls.Add(this.contraseña);
            this.Controls.Add(this.nombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labfecha;
        private System.Windows.Forms.TextBox fecha;
        private System.Windows.Forms.RadioButton login;
        private System.Windows.Forms.Button conectar;
        private System.Windows.Forms.TextBox contraseña;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button desconectar;
        private System.Windows.Forms.RadioButton ganador;
        private System.Windows.Forms.Button aceptar;
        private System.Windows.Forms.RadioButton pregunta;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.RadioButton registrarse;
        private System.Windows.Forms.RadioButton eliminar;
        private System.Windows.Forms.Button Invitar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox chat;
        private System.Windows.Forms.TextBox textoo;
        private System.Windows.Forms.Button enviar;
    }
}

